from pathlib import Path

from typing import List, Tuple

from PIL import Image

import torch

from torch.utils.data import Dataset

from torchvision import transforms



IMG_EXTS = {'.png', '.jpg', '.jpeg', '.bmp', '.tif', '.tiff'}





def _list_images(root: str) -> List[Path]:

    root_path = Path(root)

    if not root_path.exists():

        raise FileNotFoundError(f'Dataset directory not found: {root}')

    files = [p for p in root_path.rglob('*') if p.suffix.lower() in IMG_EXTS]

    if not files:

        raise RuntimeError(f'No image files found under: {root}')

    return sorted(files)





def _relative_key(path: Path, root: Path) -> str:



    return str(path.relative_to(root)).replace('\\', '/')





class PairedImageDataset(Dataset):



    def __init__(self, blur_root: str, sharp_root: str, image_size: int = 256, training: bool = True):

        self.blur_root = Path(blur_root)

        self.sharp_root = Path(sharp_root)

        blur_files = _list_images(blur_root)

        sharp_files = _list_images(sharp_root)



        sharp_map = {_relative_key(p, self.sharp_root): p for p in sharp_files}

        pairs: List[Tuple[Path, Path]] = []

        for b in blur_files:

            key = _relative_key(b, self.blur_root)

            if key in sharp_map:

                pairs.append((b, sharp_map[key]))



        if len(pairs) != len(blur_files):

            if len(blur_files) != len(sharp_files):

                raise RuntimeError(

                    f'Unable to pair blur/sharp images. blur={len(blur_files)}, sharp={len(sharp_files)}. '

                    'Use identical filenames or equal sorted file lists.'

                )

            pairs = list(zip(blur_files, sharp_files))



        self.pairs = pairs

        self.training = training

        self.transform = transforms.Compose([

            transforms.Resize((image_size, image_size), interpolation=transforms.InterpolationMode.BICUBIC),

            transforms.ToTensor(),

            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])

        ])



    def __len__(self):

        return len(self.pairs)



    def __getitem__(self, idx):

        blur_path, sharp_path = self.pairs[idx]

        blur = Image.open(blur_path).convert('RGB')

        sharp = Image.open(sharp_path).convert('RGB')

        blur = self.transform(blur)

        sharp = self.transform(sharp)

        return {

            'blur': blur,

            'sharp': sharp,

            'name': blur_path.stem,

            'relpath': str(blur_path.relative_to(self.blur_root)).replace('\\', '/')

        }

