import torch

import torch.nn as nn

import torch.nn.functional as F





class ResBlock(nn.Module):

    def __init__(self, ch):

        super().__init__()

        self.net = nn.Sequential(

            nn.Conv2d(ch, ch, 3, 1, 1), nn.InstanceNorm2d(ch, affine=True), nn.ReLU(True),

            nn.Conv2d(ch, ch, 3, 1, 1), nn.InstanceNorm2d(ch, affine=True)

        )



    def forward(self, x):

        return F.relu(x + self.net(x), inplace=True)





class DenseResBlock(nn.Module):

    def __init__(self, ch, growth=None):

        super().__init__()

        growth = growth or ch // 2

        self.c1 = nn.Conv2d(ch, growth, 3, 1, 1)

        self.c2 = nn.Conv2d(ch + growth, growth, 3, 1, 1)

        self.c3 = nn.Conv2d(ch + 2 * growth, ch, 3, 1, 1)

        self.act = nn.ReLU(True)



    def forward(self, x):

        y1 = self.act(self.c1(x))

        y2 = self.act(self.c2(torch.cat([x, y1], dim=1)))

        y3 = self.c3(torch.cat([x, y1, y2], dim=1))

        return x + 0.2 * y3





class FlowCondition(nn.Module):

    def __init__(self, feat_ch):

        super().__init__()

        self.attn = nn.Sequential(

            nn.Conv2d(2, feat_ch, 3, 1, 1), nn.ReLU(True),

            nn.Conv2d(feat_ch, feat_ch, 3, 1, 1), nn.Sigmoid()

        )

        self.sft = nn.Sequential(

            nn.Conv2d(2, feat_ch, 3, 1, 1), nn.ReLU(True),

            nn.Conv2d(feat_ch, feat_ch * 2, 3, 1, 1)

        )



    def forward_attention(self, feat, flow):

        flow = F.interpolate(flow, size=feat.shape[-2:], mode='bilinear', align_corners=False)

        return feat * (1.0 + self.attn(flow))



    def forward_sft(self, feat, flow):

        flow = F.interpolate(flow, size=feat.shape[-2:], mode='bilinear', align_corners=False)

        gamma, beta = torch.chunk(self.sft(flow), 2, dim=1)

        return feat * (1.0 + gamma) + beta





def make_base_grid(b, h, w, device, dtype):

    yy, xx = torch.meshgrid(

        torch.linspace(-1.0, 1.0, h, device=device, dtype=dtype),

        torch.linspace(-1.0, 1.0, w, device=device, dtype=dtype),

        indexing='ij'

    )

    return torch.stack([xx, yy], dim=-1).unsqueeze(0).repeat(b, 1, 1, 1)





def normalize_flow(flow):



    b, c, h, w = flow.shape

    fx = flow[:, 0] * 2.0 / max(w - 1, 1)

    fy = flow[:, 1] * 2.0 / max(h - 1, 1)

    return torch.stack([fx, fy], dim=-1)





def warp_features(feat, flow):

    flow = F.interpolate(flow, size=feat.shape[-2:], mode='bilinear', align_corners=False)

    b, _, h, w = feat.shape

    base_grid = make_base_grid(b, h, w, feat.device, feat.dtype)

    grid = base_grid + normalize_flow(flow)

    return F.grid_sample(feat, grid, mode='bilinear', padding_mode='border', align_corners=True)





class LatentFlowNet(nn.Module):

    def __init__(self, in_ch=3, base=32, flow_scale=24.0):

        super().__init__()

        self.flow_scale = flow_scale

        self.e1 = nn.Sequential(nn.Conv2d(in_ch, base, 3, 2, 1), nn.LeakyReLU(0.2, True))

        self.e2 = nn.Sequential(nn.Conv2d(base, base * 2, 3, 2, 1), nn.LeakyReLU(0.2, True))

        self.e3 = nn.Sequential(nn.Conv2d(base * 2, base * 4, 3, 2, 1), nn.LeakyReLU(0.2, True))

        self.d2 = nn.Sequential(nn.ConvTranspose2d(base * 4, base * 2, 4, 2, 1), nn.LeakyReLU(0.2, True))

        self.d1 = nn.Sequential(nn.ConvTranspose2d(base * 4, base, 4, 2, 1), nn.LeakyReLU(0.2, True))

        self.d0 = nn.Sequential(nn.ConvTranspose2d(base * 2, base, 4, 2, 1), nn.LeakyReLU(0.2, True))

        self.out = nn.Conv2d(base, 2, 3, 1, 1)



    def forward(self, x):

        e1 = self.e1(x)

        e2 = self.e2(e1)

        e3 = self.e3(e2)

        d2 = self.d2(e3)

        d1 = self.d1(torch.cat([d2, e2], dim=1))

        d0 = self.d0(torch.cat([d1, e1], dim=1))

        full = torch.tanh(self.out(d0)) * self.flow_scale

        half = F.interpolate(full, scale_factor=0.5, mode='bilinear', align_corners=False) * 0.5

        quarter = F.interpolate(full, scale_factor=0.25, mode='bilinear', align_corners=False) * 0.25

        eighth = F.interpolate(full, scale_factor=0.125, mode='bilinear', align_corners=False) * 0.125

        return {'full': full, 'half': half, 'quarter': quarter, 'eighth': eighth}





class PGOFCGenerator(nn.Module):

    def __init__(self, base=64, num_res_blocks=8):

        super().__init__()

        self.enc1 = nn.Sequential(nn.Conv2d(3, base, 7, 1, 3), nn.LeakyReLU(0.2, True))

        self.enc2 = nn.Sequential(nn.Conv2d(base, base * 2, 3, 2, 1), nn.InstanceNorm2d(base * 2, affine=True), nn.LeakyReLU(0.2, True))

        self.enc3 = nn.Sequential(nn.Conv2d(base * 2, base * 4, 3, 2, 1), nn.InstanceNorm2d(base * 4, affine=True), nn.LeakyReLU(0.2, True))

        self.enc4 = nn.Sequential(nn.Conv2d(base * 4, base * 8, 3, 2, 1), nn.InstanceNorm2d(base * 8, affine=True), nn.LeakyReLU(0.2, True))



        self.cond1 = FlowCondition(base)

        self.cond2 = FlowCondition(base * 2)

        self.cond3 = FlowCondition(base * 4)

        self.cond4 = FlowCondition(base * 8)



        blocks = []

        for i in range(num_res_blocks):

            blocks.append(DenseResBlock(base * 8) if i < 2 else ResBlock(base * 8))

        self.body = nn.Sequential(*blocks)



        self.dec3 = nn.Sequential(nn.ConvTranspose2d(base * 12, base * 4, 4, 2, 1), nn.InstanceNorm2d(base * 4, affine=True), nn.LeakyReLU(0.2, True))

        self.dec2 = nn.Sequential(nn.ConvTranspose2d(base * 6, base * 2, 4, 2, 1), nn.InstanceNorm2d(base * 2, affine=True), nn.LeakyReLU(0.2, True))

        self.dec1 = nn.Sequential(nn.ConvTranspose2d(base * 3, base, 4, 2, 1), nn.InstanceNorm2d(base, affine=True), nn.LeakyReLU(0.2, True))

        self.out = nn.Sequential(nn.Conv2d(base * 2, 3, 7, 1, 3), nn.Tanh())



    def forward(self, blur, flow_pyr):

        f = flow_pyr['full']

        e1 = self.cond1.forward_attention(self.enc1(blur), f)

        e2 = self.cond2.forward_attention(self.enc2(e1), f)

        e3 = self.cond3.forward_attention(self.enc3(e2), f)

        e4 = self.cond4.forward_attention(self.enc4(e3), f)

        b = self.body(e4)



        s3 = warp_features(e3, flow_pyr['quarter'])

        d3 = self.dec3(torch.cat([b, s3], dim=1))

        d3 = self.cond3.forward_sft(d3, f)



        s2 = warp_features(e2, flow_pyr['half'])

        d2 = self.dec2(torch.cat([d3, s2], dim=1))

        d2 = self.cond2.forward_sft(d2, f)



        s1 = warp_features(e1, flow_pyr['full'])

        d1 = self.dec1(torch.cat([d2, s1], dim=1))

        d1 = self.cond1.forward_sft(d1, f)



        return self.out(torch.cat([d1, e1], dim=1))





class PatchDiscriminator(nn.Module):

    def __init__(self, in_ch=6, base=64):

        super().__init__()

        self.net = nn.Sequential(

            nn.Conv2d(in_ch, base, 4, 2, 1), nn.LeakyReLU(0.2, True),

            nn.Conv2d(base, base * 2, 4, 2, 1), nn.InstanceNorm2d(base * 2, affine=True), nn.LeakyReLU(0.2, True),

            nn.Conv2d(base * 2, base * 4, 4, 2, 1), nn.InstanceNorm2d(base * 4, affine=True), nn.LeakyReLU(0.2, True),

            nn.Conv2d(base * 4, base * 8, 4, 1, 1), nn.InstanceNorm2d(base * 8, affine=True), nn.LeakyReLU(0.2, True),

            nn.Conv2d(base * 8, 1, 4, 1, 1)

        )



    def forward(self, x):

        return self.net(x)





class MultiScaleDiscriminator(nn.Module):

    def __init__(self):

        super().__init__()

        self.d1 = PatchDiscriminator()

        self.d2 = PatchDiscriminator()

        self.d3 = PatchDiscriminator()



    def forward(self, blur, img):

        x = torch.cat([blur, img], dim=1)

        out1 = self.d1(x)

        out2 = self.d2(F.avg_pool2d(x, 2))

        out3 = self.d3(F.avg_pool2d(x, 4))

        return [out1, out2, out3]

