import torch

import torch.nn as nn

import torch.nn.functional as F

from torchvision import models

from .models import make_base_grid, normalize_flow





def charbonnier(x, eps=1e-3):

    return torch.mean(torch.sqrt(x * x + eps * eps))





def edge_loss(pred, target):

    def grad(x):

        gx = x[:, :, :, 1:] - x[:, :, :, :-1]

        gy = x[:, :, 1:, :] - x[:, :, :-1, :]

        return gx, gy

    px, py = grad(pred)

    tx, ty = grad(target)

    return charbonnier(px - tx) + charbonnier(py - ty)





def differentiable_reblur(sharp_pred, flow, steps=9):

    b, _, h, w = sharp_pred.shape

    base = make_base_grid(b, h, w, sharp_pred.device, sharp_pred.dtype)

    flow_norm = normalize_flow(flow)

    acc = 0.0



    alphas = torch.linspace(-0.5, 0.5, steps, device=sharp_pred.device, dtype=sharp_pred.dtype)

    for a in alphas:

        grid = base + a * flow_norm

        acc = acc + F.grid_sample(sharp_pred, grid, mode='bilinear', padding_mode='border', align_corners=True)

    return acc / float(steps)





def flow_smoothness(flow, image):

    dx = flow[:, :, :, 1:] - flow[:, :, :, :-1]

    dy = flow[:, :, 1:, :] - flow[:, :, :-1, :]

    img_dx = torch.mean(torch.abs(image[:, :, :, 1:] - image[:, :, :, :-1]), dim=1, keepdim=True)

    img_dy = torch.mean(torch.abs(image[:, :, 1:, :] - image[:, :, :-1, :]), dim=1, keepdim=True)

    wx = torch.exp(-10.0 * img_dx)

    wy = torch.exp(-10.0 * img_dy)

    return torch.mean(wx * torch.abs(dx)) + torch.mean(wy * torch.abs(dy))





class VGGPerceptualLoss(nn.Module):

    def __init__(self, layers=(3, 8, 17, 26), weights=(1.0, 1.0, 1.0, 1.0)):

        super().__init__()

        vgg = models.vgg19(weights=models.VGG19_Weights.IMAGENET1K_V1).features

        self.blocks = nn.ModuleList()

        start = 0

        for end in layers:

            self.blocks.append(nn.Sequential(*[vgg[i] for i in range(start, end + 1)]))

            start = end + 1

        for p in self.parameters():

            p.requires_grad = False

        self.weights = weights

        self.register_buffer('mean', torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))

        self.register_buffer('std', torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))



    def forward(self, pred, target):

        pred = (pred + 1.0) * 0.5

        target = (target + 1.0) * 0.5

        pred = (pred - self.mean) / self.std

        target = (target - self.mean) / self.std

        loss = 0.0

        for block, w in zip(self.blocks, self.weights):

            pred = block(pred)

            target = block(target)

            loss = loss + w * F.l1_loss(pred, target)

        return loss





def discriminator_loss(pred_real, pred_fake):

    loss = 0.0

    for pr, pf in zip(pred_real, pred_fake):

        loss = loss + 0.5 * (torch.mean((pr - 1.0) ** 2) + torch.mean(pf ** 2))

    return loss / len(pred_real)





def generator_adv_loss(pred_fake):

    loss = 0.0

    for pf in pred_fake:

        loss = loss + torch.mean((pf - 1.0) ** 2)

    return loss / len(pred_fake)

