import os

import random

from pathlib import Path

import yaml

import numpy as np

import torch

from torchvision.utils import save_image





def load_config(path):

    with open(path, 'r', encoding='utf-8') as f:

        return yaml.safe_load(f)





def set_seed(seed: int = 2026):

    random.seed(seed)

    np.random.seed(seed)

    torch.manual_seed(seed)

    torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.benchmark = False

    torch.backends.cudnn.deterministic = True





def ensure_dir(path):

    Path(path).mkdir(parents=True, exist_ok=True)

    return path





def denorm(x):

    return torch.clamp((x + 1.0) * 0.5, 0.0, 1.0)





def save_triplet(blur, pred, sharp, path):

    ensure_dir(os.path.dirname(path))

    grid = torch.cat([denorm(blur), denorm(pred), denorm(sharp)], dim=0)

    save_image(grid, path, nrow=blur.size(0))

