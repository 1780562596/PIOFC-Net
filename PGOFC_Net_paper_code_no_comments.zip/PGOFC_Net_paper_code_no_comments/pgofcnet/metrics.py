import math

import torch

import torch.nn.functional as F

import numpy as np

from skimage.metrics import structural_similarity as ssim_np





def to_01(x):

    return torch.clamp((x + 1.0) * 0.5, 0.0, 1.0)





def batch_psnr(pred, target):

    pred = to_01(pred)

    target = to_01(target)

    mse = torch.mean((pred - target) ** 2, dim=(1, 2, 3))

    psnr = 10.0 * torch.log10(1.0 / (mse + 1e-10))

    return psnr.mean().item()





def batch_ssim(pred, target):

    pred = to_01(pred).detach().cpu().permute(0, 2, 3, 1).numpy()

    target = to_01(target).detach().cpu().permute(0, 2, 3, 1).numpy()

    vals = []

    for p, t in zip(pred, target):

        vals.append(ssim_np(t, p, channel_axis=2, data_range=1.0))

    return float(np.mean(vals))





def mean_std(values):

    arr = np.asarray(values, dtype=np.float64)

    return float(np.mean(arr)), float(np.std(arr, ddof=1) if len(arr) > 1 else 0.0)

