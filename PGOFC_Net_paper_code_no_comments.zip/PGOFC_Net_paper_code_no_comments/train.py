import argparse

import csv

import os

from pathlib import Path



import torch

from torch.utils.data import DataLoader

from tqdm import tqdm



from pgofcnet.dataset import PairedImageDataset

from pgofcnet.losses import (

    VGGPerceptualLoss, charbonnier, edge_loss, differentiable_reblur,

    flow_smoothness, discriminator_loss, generator_adv_loss

)

from pgofcnet.metrics import batch_psnr, batch_ssim

from pgofcnet.models import PGOFCGenerator, LatentFlowNet, MultiScaleDiscriminator

from pgofcnet.utils import load_config, set_seed, ensure_dir, save_triplet





def get_phase(iteration: int, cfg):

    if iteration <= cfg['train']['phase1_end']:

        return 1

    if iteration <= cfg['train']['phase2_end']:

        return 2

    return 3





def cycle(loader):

    while True:

        for batch in loader:

            yield batch





@torch.no_grad()

def validate(net_g, net_f, loader, device, save_dir, step, max_batches=10):

    net_g.eval(); net_f.eval()

    psnr_vals, ssim_vals = [], []

    for i, batch in enumerate(loader):

        if i >= max_batches:

            break

        blur = batch['blur'].to(device)

        sharp = batch['sharp'].to(device)

        flow = net_f(blur)

        pred = net_g(blur, flow)

        psnr_vals.append(batch_psnr(pred, sharp))

        ssim_vals.append(batch_ssim(pred, sharp))

        if i == 0:

            save_triplet(blur[:4], pred[:4], sharp[:4], os.path.join(save_dir, f'val_iter_{step:06d}.png'))

    net_g.train(); net_f.train()

    return sum(psnr_vals) / len(psnr_vals), sum(ssim_vals) / len(ssim_vals)





def main():

    parser = argparse.ArgumentParser(description='Train PGOFC-Net for physics-guided optical-flow-conditioned deblurring.')

    parser.add_argument('--config', default='configs/pgofc_gopro.yaml')

    parser.add_argument('--resume', default='', help='Path to checkpoint.')

    args = parser.parse_args()



    cfg = load_config(args.config)

    set_seed(cfg.get('seed', 2026))

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')



    out_dir = Path(cfg['output_dir'])

    ckpt_dir = ensure_dir(out_dir / 'checkpoints')

    vis_dir = ensure_dir(out_dir / 'visuals')

    ensure_dir(out_dir)



    train_set = PairedImageDataset(cfg['data']['train_blur'], cfg['data']['train_sharp'], cfg['data']['image_size'], training=True)

    val_set = PairedImageDataset(cfg['data']['val_blur'], cfg['data']['val_sharp'], cfg['data']['image_size'], training=False)

    train_loader = DataLoader(train_set, batch_size=cfg['train']['batch_size'], shuffle=True,

                              num_workers=cfg['data']['num_workers'], pin_memory=True, drop_last=True)

    val_loader = DataLoader(val_set, batch_size=cfg['train']['batch_size'], shuffle=False,

                            num_workers=max(1, cfg['data']['num_workers'] // 2), pin_memory=True)



    net_f = LatentFlowNet(in_ch=3, base=32, flow_scale=cfg['model']['flow_scale']).to(device)

    net_g = PGOFCGenerator(base=cfg['model']['base_channels'], num_res_blocks=cfg['model']['num_res_blocks']).to(device)

    net_d = MultiScaleDiscriminator().to(device)

    perc = VGGPerceptualLoss().to(device).eval()



    opt_g = torch.optim.Adam(net_g.parameters(), lr=float(cfg['train']['lr_g']), betas=(cfg['train']['beta1'], cfg['train']['beta2']))

    opt_f = torch.optim.Adam(net_f.parameters(), lr=float(cfg['train']['lr_f']), betas=(cfg['train']['beta1'], cfg['train']['beta2']))

    opt_d = torch.optim.Adam(net_d.parameters(), lr=float(cfg['train']['lr_d']), betas=(cfg['train']['beta1'], cfg['train']['beta2']))



    start_iter = 0

    if args.resume:

        ckpt = torch.load(args.resume, map_location='cpu')

        net_g.load_state_dict(ckpt['net_g'])

        net_f.load_state_dict(ckpt['net_f'])

        net_d.load_state_dict(ckpt['net_d'])

        opt_g.load_state_dict(ckpt['opt_g'])

        opt_f.load_state_dict(ckpt['opt_f'])

        opt_d.load_state_dict(ckpt['opt_d'])

        start_iter = ckpt['iter']



    csv_path = out_dir / 'training_log.csv'

    if start_iter == 0:

        with open(csv_path, 'w', newline='', encoding='utf-8') as f:

            writer = csv.writer(f)

            writer.writerow(['iter', 'phase', 'loss_g', 'loss_d', 'l1', 'edge', 'perc', 'reblur', 'smooth', 'adv', 'val_psnr', 'val_ssim'])



    train_iter = cycle(train_loader)

    pbar = tqdm(range(start_iter + 1, cfg['train']['total_iters'] + 1), desc='PGOFC-Net training')

    for it in pbar:

        phase = get_phase(it, cfg)

        batch = next(train_iter)

        blur = batch['blur'].to(device, non_blocking=True)

        sharp = batch['sharp'].to(device, non_blocking=True)





        flow = net_f(blur)

        pred = net_g(blur, flow)



        l_l1 = charbonnier(pred - sharp) * cfg['loss']['lambda_l1']

        l_edge = edge_loss(pred, sharp) * cfg['loss']['lambda_edge']

        l_perc = torch.tensor(0.0, device=device)

        l_reblur = torch.tensor(0.0, device=device)

        l_smooth = torch.tensor(0.0, device=device)

        l_adv = torch.tensor(0.0, device=device)



        if phase >= 2:

            reblur = differentiable_reblur(pred, flow['full'], steps=cfg['model']['reblur_steps'])

            l_reblur = charbonnier(reblur - blur) * cfg['loss']['lambda_reblur']

            l_smooth = flow_smoothness(flow['full'], blur) * cfg['loss']['lambda_flow_smooth']



        if phase >= 3:

            l_perc = perc(pred, sharp) * cfg['loss']['lambda_perc']

            fake_scores = net_d(blur, pred)

            l_adv = generator_adv_loss(fake_scores) * cfg['loss']['lambda_adv']



        loss_g = l_l1 + l_edge + l_perc + l_reblur + l_smooth + l_adv

        opt_g.zero_grad(set_to_none=True)

        opt_f.zero_grad(set_to_none=True)

        loss_g.backward()

        torch.nn.utils.clip_grad_norm_(net_g.parameters(), cfg['train']['max_grad_norm'])

        torch.nn.utils.clip_grad_norm_(net_f.parameters(), cfg['train']['max_grad_norm'])

        opt_g.step()

        if phase >= 2:

            opt_f.step()





        loss_d_val = 0.0

        if phase >= 3:

            with torch.no_grad():

                flow_det = net_f(blur)

                pred_det = net_g(blur, flow_det)

            real_scores = net_d(blur, sharp)

            fake_scores = net_d(blur, pred_det.detach())

            loss_d = discriminator_loss(real_scores, fake_scores)

            opt_d.zero_grad(set_to_none=True)

            loss_d.backward()

            torch.nn.utils.clip_grad_norm_(net_d.parameters(), cfg['train']['max_grad_norm'])

            opt_d.step()

            loss_d_val = float(loss_d.item())



        val_psnr = val_ssim = None

        if it % cfg['train']['val_every'] == 0 or it == 1:

            val_psnr, val_ssim = validate(net_g, net_f, val_loader, device, str(vis_dir), it)



        if it % cfg['train']['log_every'] == 0 or it == 1:

            with open(csv_path, 'a', newline='', encoding='utf-8') as f:

                writer = csv.writer(f)

                writer.writerow([

                    it, phase, float(loss_g.item()), loss_d_val,

                    float(l_l1.item()), float(l_edge.item()), float(l_perc.item()),

                    float(l_reblur.item()), float(l_smooth.item()), float(l_adv.item()),

                    '' if val_psnr is None else val_psnr,

                    '' if val_ssim is None else val_ssim,

                ])

            pbar.set_postfix(phase=phase, loss_g=f'{loss_g.item():.4f}', loss_d=f'{loss_d_val:.4f}')



        if it % cfg['train']['save_every'] == 0 or it == cfg['train']['total_iters']:

            torch.save({

                'iter': it,

                'net_g': net_g.state_dict(),

                'net_f': net_f.state_dict(),

                'net_d': net_d.state_dict(),

                'opt_g': opt_g.state_dict(),

                'opt_f': opt_f.state_dict(),

                'opt_d': opt_d.state_dict(),

                'config': cfg,

            }, Path(ckpt_dir) / f'pgofc_iter_{it:06d}.pth')





if __name__ == '__main__':

    main()

