#!/usr/bin/env bash
set -e
CKPT=$1
CFG=${2:-configs/pgofc_gopro.yaml}

python test.py --config $CFG --checkpoint $CKPT --dataset_name GoPro \
  --blur_dir /path/to/GOPRO/test/blur --sharp_dir /path/to/GOPRO/test/sharp
python test.py --config $CFG --checkpoint $CKPT --dataset_name GS-Blur \
  --blur_dir /path/to/GS-Blur/test/blur --sharp_dir /path/to/GS-Blur/test/sharp
python test.py --config $CFG --checkpoint $CKPT --dataset_name Flow-Blur \
  --blur_dir /path/to/Flow-Blur/test/blur --sharp_dir /path/to/Flow-Blur/test/sharp
python test.py --config $CFG --checkpoint $CKPT --dataset_name MVTec-AD-Blur \
  --blur_dir /path/to/MVTec-AD-Blur/test/blur --sharp_dir /path/to/MVTec-AD-Blur/test/clear
