import argparse

import csv

from pathlib import Path



import torch

from torch.utils.data import DataLoader

from tqdm import tqdm



try:

    import lpips

except Exception:

    lpips = None



from pgofcnet.dataset import PairedImageDataset

from pgofcnet.metrics import batch_psnr, batch_ssim, mean_std

from pgofcnet.models import PGOFCGenerator, LatentFlowNet

from pgofcnet.utils import load_config, set_seed, ensure_dir, save_triplet





@torch.no_grad()

def main():

    parser = argparse.ArgumentParser(description='Evaluate PGOFC-Net on a paired deblurring dataset.')

    parser.add_argument('--config', default='configs/pgofc_gopro.yaml')

    parser.add_argument('--checkpoint', required=True)

    parser.add_argument('--blur_dir', default='', help='Override test blur directory.')

    parser.add_argument('--sharp_dir', default='', help='Override test sharp directory.')

    parser.add_argument('--save_images', action='store_true')

    parser.add_argument('--dataset_name', default='test')

    args = parser.parse_args()



    cfg = load_config(args.config)

    set_seed(cfg.get('seed', 2026))

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')



    blur_dir = args.blur_dir or cfg['data']['test_blur']

    sharp_dir = args.sharp_dir or cfg['data']['test_sharp']

    out_dir = Path(cfg['output_dir']) / 'eval' / args.dataset_name

    img_dir = ensure_dir(out_dir / 'images')

    ensure_dir(out_dir)



    dataset = PairedImageDataset(blur_dir, sharp_dir, cfg['data']['image_size'], training=False)

    loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=cfg['data']['num_workers'], pin_memory=True)



    ckpt = torch.load(args.checkpoint, map_location='cpu')

    net_f = LatentFlowNet(in_ch=3, base=32, flow_scale=cfg['model']['flow_scale']).to(device)

    net_g = PGOFCGenerator(base=cfg['model']['base_channels'], num_res_blocks=cfg['model']['num_res_blocks']).to(device)

    net_g.load_state_dict(ckpt['net_g'], strict=True)

    net_f.load_state_dict(ckpt['net_f'], strict=True)

    net_g.eval(); net_f.eval()



    lpips_fn = None

    if lpips is not None:

        lpips_fn = lpips.LPIPS(net='vgg').to(device).eval()



    psnr_vals, ssim_vals, lpips_vals = [], [], []

    rows = []

    for idx, batch in enumerate(tqdm(loader, desc=f'Evaluating {args.dataset_name}')):

        blur = batch['blur'].to(device)

        sharp = batch['sharp'].to(device)

        flow = net_f(blur)

        pred = net_g(blur, flow)



        p = batch_psnr(pred, sharp)

        s = batch_ssim(pred, sharp)

        if lpips_fn is not None:



            l = float(lpips_fn(pred, sharp).mean().item())

        else:

            l = float('nan')

        psnr_vals.append(p); ssim_vals.append(s); lpips_vals.append(l)

        rows.append([batch['relpath'][0], p, s, l])

        if args.save_images:

            stem = Path(batch['relpath'][0]).with_suffix('').as_posix().replace('/', '_')

            save_triplet(blur, pred, sharp, str(Path(img_dir) / f'{stem}.png'))



    psnr_m, psnr_s = mean_std(psnr_vals)

    ssim_m, ssim_s = mean_std(ssim_vals)

    lpips_m, lpips_s = mean_std([x for x in lpips_vals if x == x]) if lpips_fn is not None else (float('nan'), float('nan'))



    with open(out_dir / 'per_image_metrics.csv', 'w', newline='', encoding='utf-8') as f:

        writer = csv.writer(f)

        writer.writerow(['image', 'PSNR', 'SSIM', 'LPIPS'])

        writer.writerows(rows)



    with open(out_dir / 'summary.csv', 'w', newline='', encoding='utf-8') as f:

        writer = csv.writer(f)

        writer.writerow(['dataset', 'num_images', 'PSNR_mean', 'PSNR_std', 'SSIM_mean', 'SSIM_std', 'LPIPS_mean', 'LPIPS_std'])

        writer.writerow([args.dataset_name, len(dataset), psnr_m, psnr_s, ssim_m, ssim_s, lpips_m, lpips_s])



    print(f'{args.dataset_name}: PSNR={psnr_m:.3f}±{psnr_s:.3f}, SSIM={ssim_m:.4f}±{ssim_s:.4f}, LPIPS={lpips_m:.4f}±{lpips_s:.4f}')





if __name__ == '__main__':

    main()

