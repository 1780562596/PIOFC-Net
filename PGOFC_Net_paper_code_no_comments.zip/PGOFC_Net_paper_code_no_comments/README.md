# PGOFC-Net: Paper-level Reference Code

This repository provides a reproducible PyTorch implementation of **PGOFC-Net** for physics-guided optical-flow-conditioned image deblurring.
It is designed to match the paper description more closely than a single monolithic training script.

## Main features

- Single-image latent exposure motion estimator (**Flow-Net**).
- Optical-flow-conditioned generator with:
  - motion attention in the encoder,
  - flow-guided skip feature warping,
  - SFT-style motion modulation in the decoder.
- Multi-scale PatchGAN discriminator used only during adversarial refinement.
- Differentiable forward reblur operator implemented with `torch.nn.functional.grid_sample`.
- Official LPIPS evaluation interface through the `lpips` package.
- Reproducible training with a fixed random seed, CSV logs, checkpoints, and validation images.
- Dataset interfaces for GoPro, GS-Blur, Flow-Blur, and MVTec-AD-Blur.

## Folder structure

```text
PGOFC_Net_paper_code/
  configs/
    pgofc_gopro.yaml
  pgofcnet/
    dataset.py
    losses.py
    metrics.py
    models.py
    utils.py
  train.py
  test.py
  cross_dataset_eval.sh
  requirements.txt
  README.md
```

## Dataset format

Each dataset should be organized as paired blur/sharp folders. Nested subfolders are supported if the relative paths match.

```text
GOPRO/
  train/
    input/...
    target/...
  test/
    blur/...
    sharp/...
```

For Flow-Blur and MVTec-AD-Blur, use the same paired-folder style:

```text
Flow-Blur/
  train/blur/...
  train/clear/...
  val/blur/...
  val/clear/...
  test/blur/...
  test/clear/...

MVTec-AD-Blur/
  train/blur/...
  train/clear/...
  val/blur/...
  val/clear/...
  test/blur/...
  test/clear/...
```

## Installation

```bash
conda create -n pgofc python=3.10 -y
conda activate pgofc
pip install -r requirements.txt
```

Install a CUDA-matched PyTorch version if needed from the official PyTorch instructions.

## Training

Edit `configs/pgofc_gopro.yaml` and replace the dataset paths.

```bash
python train.py --config configs/pgofc_gopro.yaml
```

The training schedule follows the paper:

1. Reconstruction pretraining: generator + reconstruction losses.
2. Physical embedding learning: generator + Flow-Net + differentiable reblur consistency.
3. Adversarial refinement: generator + Flow-Net + multi-scale discriminator + perceptual loss.

## Testing

```bash
python test.py \
  --config configs/pgofc_gopro.yaml \
  --checkpoint paper_results/pgofc_gopro/checkpoints/pgofc_iter_240000.pth \
  --dataset_name GoPro \
  --save_images
```

The script writes:

- `per_image_metrics.csv`
- `summary.csv`
- visual blur/prediction/sharp comparison images when `--save_images` is enabled.

## Cross-dataset testing

```bash
bash cross_dataset_eval.sh paper_results/pgofc_gopro/checkpoints/pgofc_iter_240000.pth configs/pgofc_gopro.yaml
```

Replace the dataset paths inside `cross_dataset_eval.sh` before running.

## Notes for paper use

This implementation treats the Flow-Net output as a **latent exposure motion field**, not as conventional two-frame optical flow. This wording is safer for single-image deblurring and should be used consistently in the manuscript.

The differentiable reblur operator is implemented as centered exposure accumulation:

```text
I_reblur = 1/K * sum_k grid_sample(I_hat, base_grid + alpha_k * F)
```

where `alpha_k` is uniformly sampled from `[-0.5, 0.5]`. This keeps gradients flowing to both the restored image and the latent motion estimator.
